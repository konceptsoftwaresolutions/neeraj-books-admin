import React from "react";
import PageCont from "../../components/PageCont";

const ViewOrder = () => {
  return <PageCont></PageCont>;
};

export default ViewOrder;
